# Introduction

Opensearch deployment with helm chars in opensearch namespace with master data and client nodes

# Getting Started

This will be done with the pipeline

1. Installation process
2. Software dependencies
3. Latest releases
4. API references

# Build and Test

TODO: Describe and show how to build your code and run the tests.

